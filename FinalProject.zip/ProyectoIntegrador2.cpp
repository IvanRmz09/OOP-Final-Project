#include <iostream>
#include <vector>
#include <string>
#include<fstream>
#include<sstream>

#include "Pelicula.h"
#include "Episodio.h"
#include "Serie.h"
#include "Plataforma.h"

using namespace std;

int forzarInt()
{
	int num;
	cin >> num;
	while (true)
	{
		if (cin.fail())
		{
			cin.clear();
			cin.ignore();
			cout << "Debe ingresar un numero valido: "; cin >> num;
		}
		else
		{
			return num;
			break;
		}
	}
}

double forzarDouble()
{
	double num;
	cin >> num;
	while (true)
	{
		if (cin.fail())
		{
			cin.clear();
			cin.ignore();
			cout << "Debe ingresar un numero valido: "; cin >> num;
		}
		else
		{
			return num;
			break;
		}
	}
}

int main()
{
	//Variables
	int respInt, valorInt, opcion;
	int id, temporada;
	double calif, respDouble;
	string nombre, duracion, genero, idEpisodio, respString, archive1, archive2, archive3;
	vector<Video*> peliEp;
	vector<Episodio*> episodios;
	vector<Serie*> series;
	string line, valor;
	char delim = ',';
	int col, cont = 0;

	//Despliega Menu
	cout << "                  **Bienvenido a ServiStream**" << endl;
	do {

		cout << "-----------------------Menu de acciones----------------------" << endl;
		cout << "1. Cargar los datos a la plataforma" << endl;
		cout << "2. Mostrar contenido por calificacion y genero" << endl;
		cout << "3. Mostrar contenido por genero" << endl;
		cout << "4. Mostrar episodios de una serie por calificacion" << endl;
		cout << "5. Mostrar peliculas por calificacion" << endl;
		cout << "6. Calificar una pelicula o episodio" << endl;
		cout << "0. Salir de la plataforma" << endl;
		opcion = forzarInt();
		switch (opcion)
		{
		case 1:
			cont = 0;
			archive1 = "PLS.csv"; //Archivos Reales
			archive2 = "SRS.csv";
			archive3 = "EPS.csv";

			//PELICULAS
			ifstream archivo1(archive1);
			try
			{
				if (!archivo1.is_open())
				{
					throw runtime_error("Lista de Peliculas no encontrada ");
				}
				else {
					cont += 1;
					getline(archivo1, line); // Lee primer renglon
					while (getline(archivo1, line))
					{
						stringstream ss(line);
						col = 0;
						while (getline(ss, valor, delim))
						{
							switch (col)
							{
							case 0:
								id = stoi(valor);
								break;
							case 1:
								nombre = valor;
								break;
							case 2:
								duracion = valor;
								break;
							case 3:
								genero = valor;
								break;
							case 4:
								calif = stod(valor);
								break;
							}
							col++;
						}
						peliEp.push_back(new Pelicula(id, nombre, duracion, genero, calif));
					}
					cout << "Archivo " << archive1 << " se abrio correctamente" << endl;
					archivo1.close();
				}
			}
			catch (runtime_error& e1) {
				cout << e1.what() << endl;
			}

			//SERIES
			ifstream archivo2(archive2);
			try
			{
				if (!archivo2.is_open())
				{
					throw runtime_error("Lista de Series no encontrada");
				}
				else {
					cont += 1;
					ifstream archivo2(archive2);
					getline(archivo2, line); // Lee primer renglon
					while (getline(archivo2, line)) {
						stringstream ss(line);
						col = 0;
						while (getline(ss, valor, delim)) {
							switch (col) {
							case 0:
								id = stoi(valor);
								break;
							case 1:
								nombre = valor;
								break;
							case 2:
								genero = valor;
								break;
							case 3:
								temporada = stoi(valor);
								break;
							}
							col++;
						}
						series.push_back(new Serie(id, nombre, genero, temporada));
					}
					cout << "Archivo " << archive2 << " se abrio correctamente " << endl;
					archivo2.close();
				}
			}
			catch (runtime_error& e2) {
				cout << e2.what() << endl;
			}

			//EPISODIOS
			ifstream archivo3(archive3);
			try
			{
				if (!archivo3.is_open())
				{
					throw runtime_error("Lista de Episodios no encontrada");
				}
				else {
					cont += 1;
					ifstream archivo3("EPS.csv");
					getline(archivo3, line); // Lee primer renglon
					while (getline(archivo3, line)) {
						stringstream ss(line);
						col = 0;
						while (getline(ss, valor, delim)) {
							switch (col) {
							case 0:
								id = stoi(valor);
								break;
							case 1:
								idEpisodio = valor;
								break;
							case 2:
								nombre = valor;
								break;
							case 3:
								duracion = valor;
								break;
							case 4:
								calif = stod(valor);
								break;
							case 5:
								temporada = stoi(valor);
								break;
							}
							col++;
						}
						for (int i = 0; i < series.size(); i++) {
							if (series[i]->getId() == id) {
								genero = series[i]->getGenero();
							}
						}
						episodios.push_back(new Episodio(id, nombre, duracion, genero, calif, idEpisodio, temporada));
					}
					cout << "Archivo " << archive3 << " se abrio correctamente" << endl;
					archivo3.close();
				}
			}
			catch (runtime_error& e3) {
				cout << e3.what() << endl;
			}
			cout << endl;
			cout << endl;
			cout << endl;
			break;
		}

		for (int i = 0; i < episodios.size(); i++)
		{
			for (int j = 0; j < series.size(); j++)
			{
				if (episodios[i]->getId() == series[j]->getId())
				{
					*series[j] + episodios[i];
				}
			}
		}

		Plataforma plat(peliEp, series, episodios);

		switch (opcion)
		{
		case 2:
			if (cont != 3)
			{
				cout << "Falta contenido para la busqueda, cargar archivo" << endl;
				cout << endl;
				cout << endl;
				cout << endl;
				break;
			}
			cout << "----------------Filtro: Calificacion y Genero----------------" << endl;
			cout << "Ingresa la calificacion minima para el contenido: "; respDouble = forzarDouble();
			while (respDouble > 10.0 || respDouble < 0.0)
			{
				cout << "Intenta con un valor menor igual a 10 y mayor igual que 0: "; respDouble = forzarDouble();
			}
			cout << "Generos Disponibles: " << endl;
			cout << "1. Accion" << endl;
			cout << "2. Drama" << endl;
			cout << "3. Misterio" << endl;
			respInt = forzarInt();
			while (respInt > 3 || respInt < 1)
			{
				cout << "Intenta con un valor menor igual a 3 y mayor igual que 1: "; respInt = forzarInt();
			}
			switch (respInt)
			{
			case 1:
				respString = "Accion";
				break;
			case 2:
				respString = "Drama";
				break;
			case 3:
				respString = "Misterio";
				break;
			}
			plat.showCalifGen(respDouble, respString);
			cout << endl;
			cout << endl;
			cout << endl;
			break;
		case 3:
			if (cont != 3)
			{
				cout << "Falta contenido para la busqueda, cargar archivo" << endl;
				cout << endl;
				cout << endl;
				cout << endl;
				break;
			}
			cout << "-----------------------Filtro: Genero-----------------------" << endl;
			cout << "Generos Disponibles: " << endl;
			cout << "1. Accion" << endl;
			cout << "2. Drama" << endl;
			cout << "3. Misterio" << endl;
			respInt = forzarInt();
			while (respInt > 3 || respInt < 1)
			{
				cout << "Intenta con un valor menor igual a 3 y mayor igual que 1: "; respInt = forzarInt();
			}
			switch (respInt)
			{
			case 1:
				respString = "Accion";
				break;
			case 2:
				respString = "Drama";
				break;
			case 3:
				respString = "Misterio";
				break;
			}
			plat.showPorGenero(respString);
			cout << endl;
			cout << endl;
			cout << endl;
			break;
		case 4:
			if (cont != 3)
			{
				cout << "Falta contenido para la busqueda, cargar archivo" << endl;
				cout << endl;
				cout << endl;
				cout << endl;
				break;
			}
			cout << "----------------Filtro: Serie y Calificacion----------------" << endl;
			plat.showSeries();
			respInt = forzarInt();
			while (respInt >= series.size() || respInt <= 0)
			{
				cout << "Intenta con un valor menor igual a " << series.size() << " y mayor que 0: "; respInt = forzarInt();
			}
			for (int i = 0; i < series.size(); i++)
			{
				if ((respInt - 1) == i) {
					respInt = series[i]->getId();
				}
			}
			cout << "Ingresa la calificacion minima para el contenido: "; respDouble = forzarDouble();
			while (respDouble > 10.0 || respDouble < 0.0)
			{
				cout << "Intenta con un valor menor igual a 10 y mayor igual que 0: "; respDouble = forzarDouble();
			}
			plat.showSerieCalif(respInt, respDouble);
			cout << endl;
			cout << endl;
			cout << endl;
			break;
		case 5:
			if (cont != 3)
			{
				cout << "Falta contenido para la busqueda, cargar archivo" << endl;
				cout << endl;
				cout << endl;
				cout << endl;
				break;
			}
			cout << "--------------------Filtro: Calificacion--------------------" << endl;
			cout << "Ingresa la calificacion minima para el contenido: "; respDouble = forzarDouble();
			while (respDouble > 10.0 || respDouble < 0.0)
			{
				cout << "Intenta con un valor menor igual a 10 y mayor igual que 0: "; respDouble = forzarDouble();
			}
			plat << respDouble;
			cout << endl;
			cout << endl;
			cout << endl;
			break;
		case 6:
			if (cont != 3)
			{
				cout << "Falta contenido para la busqueda, cargar archivo" << endl;
				cout << endl;
				cout << endl;
				cout << endl;
				break;
			}
			cout << "-----------------------Calificar Video----------------------" << endl;
			cout << "Deseas calificar una pelicula o un episodio?" << endl;
			cout << "1. Pelicula" << endl;
			cout << "2. Episodio" << endl;
			respInt = forzarInt();
			while (respInt >= 3 || respInt <= 0)
			{
				cout << "Intenta con un valor menor igual a 2 y mayor que 0: "; respInt = forzarInt();
			}
			switch (respInt)
			{
			case 1:
				plat.showPeliculas();
				cout << "Ingresa la pelicula que vas a calificar: "; respInt = forzarInt();
				while (respInt > peliEp.size() || respInt <= 0) {
					cout << "Intenta con un valor menor igual a " << peliEp.size() << " y mayor que 0: "; respInt = forzarInt();
				}
				cout << "Ingresa la calificacion: "; respDouble = forzarDouble();
				while (respDouble > 10.0 || respDouble < 0.0) {
					cout << "Intenta con un valor menor igual a 10 y mayor igual que 0: "; respDouble = forzarDouble();
				}
				*peliEp[respInt - 1] >> respDouble;
				plat.setPelicula(peliEp);
				break;
			case 2:
				plat.showSeries();
				respInt = forzarInt();
				while (respInt > series.size() || respInt <= 0) {
					cout << "Intenta con un valor menor a " << series.size() << " y mayor que 0: "; respInt = forzarInt();
				}
				for (int i = 0; i < series.size(); i++)
				{
					if ((respInt - 1) == i) {
						respInt = series[i]->getId();
					}
				}
				plat.showEpisodios(respInt);
				cout << "Que episodio vas a calificar? "; respInt = forzarInt();
				while (respInt > episodios.size() || respInt <= 0) {
					cout << "Intenta con un valor menor igual a " << episodios.size() << " y mayor que 0: "; respInt = forzarInt();
				}
				cout << "Ingresa la calificacion: "; respDouble = forzarDouble();
				while (respDouble > 10.0 || respDouble < 0.0) {
					cout << "Intenta con un valor menor igual a 10 y mayor igual que 0: "; respDouble = forzarDouble();
				}
				*episodios[respInt - 1] >> respDouble;
				plat.setEpisodio(episodios);
				break;
			}
			cout << endl;
			cout << endl;
			cout << endl;
			break;
		case 0:
			cout << "Vuelva pronto..." << endl;
			cout << endl;
			cout << endl;
			cout << endl;
			exit(1);

		default:
			if(opcion <0 || opcion>6)
			{
				cout << "Respuesta invalida intentelo de nuevo por favor" << endl;
				cout << endl;
				cout << endl;
				cout << endl;
			}
		}

	} while (true);
	return 0;
}