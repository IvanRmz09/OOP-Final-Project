#pragma once
#include <iostream>
#include <string>

using namespace std;

class Video
{
protected:
	int id;
	string nombre;
	string duracion;
	string genero;
	double calif;

public:
	Video();
	Video(int, string, string, string, double);
	void setId(int);
	void setNombre(string);
	void setDuracion(string);
	void setGenero(string);
	void setCalif(double);
	int getId();
	string getNombre();
	string getDuracion();
	string getGenero();
	double getCalif();
	virtual void operator>>(double) = 0;
	virtual void show() = 0;
};

Video::Video()
{
	id = 87654321;
	nombre = "Nombre";
	duracion = "00:00";
	genero = "None";
	calif = 0.0;
}

Video::Video(int id, string nombre, string duracion, string genero, double calif)
{
	this->id = id;
	this->nombre = nombre;
	this->duracion = duracion;
	this->genero = genero;
	this->calif = calif;
}

void Video::setId(int id)
{
	this->id = id;
}

void Video::setNombre(string nombre)
{
	this->nombre = nombre;
}

void Video::setDuracion(string duracion)
{
	this->duracion = duracion;
}

void Video::setGenero(string genero)
{
	this->genero = genero;
}

void Video::setCalif(double calif)
{
	this->calif = calif;
}

int Video::getId()
{
	return id;
}

string Video::getNombre()
{
	return nombre;
}

string Video::getDuracion()
{
	return duracion;
}

string Video::getGenero()
{
	return genero;
}

double Video::getCalif()
{
	return calif;
}