#pragma once
#include <iostream>
#include <string>

#include "Video.h"

using namespace std;

class Episodio :public Video
{
protected:
	string idEpisodio;
	int temporada;

public:
	Episodio();
	Episodio(int, string, string, string, double, string, int);
	void setIdEpisodio(string);
	void setTemporada(int);
	string getIdEpisodio();
	int getTemporada();
	void operator>>(double);
	void show();
};

Episodio::Episodio() :Video()
{
	idEpisodio = "87654321-S01E01";
	temporada = 1;
}

Episodio::Episodio(int id, string nombre, string duracion, string genero, double calif, string idEpisodio, int temporada) :
	Video(id, nombre, duracion, genero, calif)
{
	this->idEpisodio = idEpisodio;
	this->temporada = temporada;
}

void Episodio::setIdEpisodio(string idEpisodio)
{
	this->idEpisodio = idEpisodio;
}

void Episodio::setTemporada(int temporada)
{
	this->temporada = temporada;
}

string Episodio::getIdEpisodio()
{
	return idEpisodio;
}

int Episodio::getTemporada() {
	return temporada;
}

void Episodio::operator>>(double calif)
{
	this->calif = calif;
}

void Episodio::show()
{
	cout << "- Titulo: " << nombre << "            Duracion: " << duracion << "            Temporada: " << temporada << "            Calificacion: " << calif << endl;
}