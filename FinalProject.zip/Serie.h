#pragma once
#include <iostream>
#include <string>
#include <vector>

#include "Episodio.h"

using namespace std;

class Serie
{
private:
	int id;
	string nombre;
	string genero;
	int temporada;
	vector<Video*> episodios;

public:
	Serie();
	Serie(int, string, string, int);
	void setId(int);
	void setNombre(string);
	void setGenero(string);
	void setTemporada(int);
	void setEpisodios(vector<Video*>);
	int getId();
	string getNombre();
	string getGenero();
	int getTemporada();
	void operator+(Video*);
	void show();
};

Serie::Serie()
{
	id = 12345678;
	nombre = "Nombre";
	genero = "None";
	temporada = 1;
}

Serie::Serie(int id, string nombre, string genero, int temporada)
{
	this->id = id;
	this->nombre = nombre;
	this->genero = genero;
	this->temporada = temporada;
}

void Serie::setId(int id)
{
	this->id = id;
}

void Serie::setNombre(string nombre)
{
	this->nombre = nombre;
}

void Serie::setGenero(string genero)
{
	this->genero = genero;
}

void Serie::setTemporada(int temporada)
{
	this->temporada = temporada;
}

void Serie::setEpisodios(vector<Video*> episodios)
{
	this->episodios = episodios;
}

int Serie::getId()
{
	return id;
}

string Serie::getNombre()
{
	return nombre;
}

string Serie::getGenero()
{
	return genero;
}

int Serie::getTemporada()
{
	return temporada;
}

void Serie::operator+(Video* episodio)
{
	episodios.push_back(episodio);
}

void Serie::show()
{
	cout <<" - Titulo: " << nombre << endl;
}