#pragma once
#include <iostream>
#include <vector>
#include <string>

#include "Pelicula.h"
#include "Episodio.h"
#include "Serie.h"
#include "Video.h"

using namespace std;

class Plataforma
{
private:
	vector<Video*> peliEp;
	vector<Serie*> series;
	vector<Episodio*> episodios;

public:
	Plataforma(vector<Video*>, vector<Serie*>, vector<Episodio*>);
	void setPelicula(vector<Video*>);
	void setEpisodio(vector<Episodio*>);
	void showCalifGen(double, string);
	void showSerieCalif(int, double);
	void showPorGenero(string);
	void operator<<(double);
	void showPeliculas();
	void showEpisodios(int);
	void showSeries();
};

Plataforma::Plataforma(vector<Video*> peliEp, vector<Serie*> series, vector<Episodio*> episodios)
{
	this->peliEp = peliEp;
	this->series = series;
	this->episodios = episodios;
}

void Plataforma::setPelicula(vector<Video*> peliEp)
{
	this->peliEp = peliEp;
}

void Plataforma::setEpisodio(vector<Episodio*> episodios)
{
	this->episodios = episodios;
}

void Plataforma::showCalifGen(double calif, string genero)
{
	cout << "----------------Peliculas----------------" << endl;
	for (int i = 0; i < peliEp.size(); i++)
	{
		if (peliEp[i]->getCalif() >= calif && peliEp[i]->getGenero() == genero)
		{
			peliEp[i]->show();
		}
	}
	cout << endl;
	cout << "----------------Episodios----------------" << endl;
	for (int i = 0; i<series.size(); i++)
	{
		series[i]->show();
		for (int j = 0; j < episodios.size(); j++)
		{
			if (episodios[j]->getCalif() >= calif && episodios[j]->getGenero() == genero)
			{
				if (series[i]->getId() == episodios[j]->getId())
				{
					episodios[j]->show();
				}
			}
		}
	}
}

void Plataforma::showSerieCalif(int id, double calif)
{
	cout << "----------------Episodios----------------" << endl;
	for (int i = 0; i < series.size(); i++)
	{
		series[i]->show();
		for (int j = 0; j < episodios.size(); j++)
		{
			if (episodios[i]->getId() == id && episodios[i]->getCalif() >= calif)
			{
				if (series[i]->getId() == episodios[j]->getId())
				{
					episodios[j]->show();
				}
			}
		}
	}
}

void Plataforma::showPorGenero(string genero) 
{
	cout << "----------------Peliculas----------------" << endl;
	for (int i = 0; i < peliEp.size(); i++)
	{
		if (peliEp[i]->getGenero() == genero)
		{
			peliEp[i]->show();
		}
	}
	cout << endl;
	cout << "----------------Episodios----------------" << endl;
	for (int i = 0; i < series.size(); i++)
	{
		series[i]->show();
		for (int j = 0; j < episodios.size(); j++)
		{
			if (episodios[i]->getGenero() == genero)
			{
				if (series[i]->getId() == episodios[j]->getId())
				{
					episodios[j]->show();
				}
			}
		}
	}
}

void Plataforma::operator<<(double calif)
{
	cout << "----------------Peliculas----------------" << endl;
	for (int i = 0; i < peliEp.size(); i++)
	{
		if (peliEp[i]->getCalif() >= calif)
		{
			peliEp[i]->show();
		}
	}
}

void Plataforma::showPeliculas()
{
	cout << "----------------Peliculas----------------" << endl;
	for (int i = 0; i < peliEp.size(); i++)
	{
		peliEp[i]->show();
	}
}

void Plataforma::showEpisodios(int id)
{
	cout << "----------------Episodios----------------" << endl;
	for (int i = 0; i < series.size(); i++)
	{
		series[i]->show();
		for (int j = 0; j < episodios.size(); j++)
		{
			if (episodios[i]->getId() == id)
			{
				if (series[i]->getId() == episodios[j]->getId())
				{
					episodios[j]->show();
				}
			}
		}
	}
}

void Plataforma::showSeries()
{
	cout << "-----------------Series------------------" << endl;
	for (int i = 0; i < series.size(); i++)
	{
		cout << i + 1 << "- Titulo: " << series[i]->getNombre() << endl;
	}
}