#pragma once
#include <iostream>
#include <string>

#include "Video.h"

using namespace std;

class Pelicula : public Video
{
public:
	Pelicula();
	Pelicula(int, string, string, string, double);
	void operator>>(double);
	void show();
};

Pelicula::Pelicula() :Video()
{

}

Pelicula::Pelicula(int id, string nombre, string duracion, string genero, double calif) : Video(id, nombre, duracion, genero, calif)
{

}

void Pelicula::operator>>(double calif)
{
	this->calif = calif;
}

void Pelicula::show()
{
	cout << "- Titulo: "<< nombre << "            Duracion: " << duracion << "            Calificacion: " << calif << endl;
}